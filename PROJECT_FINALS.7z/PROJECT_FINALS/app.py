from flask import Flask, render_template, session, request, redirect, url_for, jsonify
import sqlite3
import hashlib

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # You should set a secret key for session management

# SQLite database connection
def get_db_connection():
    conn = sqlite3.connect('students.db')
    conn.row_factory = sqlite3.Row  # To work with columns as dictionaries
    return conn

# Home Route (Redirect to Login)
@app.route('/')
def home():
    return redirect(url_for('login'))

# Route to display the registration form
@app.route('/register', methods=['GET'])
def register_page():
    return render_template('registration.html')  # Render the registration form

# Route to handle the form submission for registration
@app.route('/register', methods=['POST'])
def register():
    if request.method == 'POST':
        # Get the form data
        idno = request.form['idno']
        lastname = request.form['lastname']
        firstname = request.form['firstname']
        middlename = request.form['middlename']
        course = request.form['course']
        year_level = request.form['year_level']
        email = request.form['email']
        username = request.form['username']
        password = request.form['password']

        # Hash the password before storing it
        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        # Connect to the database and insert the data
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute('''
            INSERT INTO users (idno, lastname, firstname, middlename, course, year_level, email, username, password)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (idno, lastname, firstname, middlename, course, year_level, email, username, hashed_password))

        conn.commit()
        conn.close()

        return redirect(url_for('login'))  # Redirect to the login route after successful registration

# Route for login page (this handles both GET and POST methods)
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Get the login data from the form
        username = request.form['username']
        password = request.form['password']
        
        # Hash the password to compare securely with stored hashed passwords
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        
        # Check credentials in the database
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, hashed_password))
        user = cursor.fetchone()

        conn.close()

        if user:
            # Store user_id in session
            session['user_id'] = user['idno']
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'Invalid credentials. Please try again.'})

    return render_template('login.html')  # Render the login page for GET request

# Route for user dashboard page
@app.route('/user_dashboard')
def user_dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))  # Redirect to login if user is not logged in

    # Get user data from the database
    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE idno = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()

    if user:
        # Assuming there is a 'sessions_left' field or you want to simulate it:
        sessions_left = 30  # Static sessions left for now

        return render_template('user_dashboard.html', user=user, sessions_left=sessions_left)

    return redirect(url_for('login'))  # Redirect to login if user is not found



@app.route("/add_sit_in", methods=["POST"])
def add_sit_in():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))

    # Deduct a session from the user
    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()

    # Fetch current sessions left for user
    cursor.execute("SELECT sessions_left FROM users WHERE idno = ?", (user_id,))
    user = cursor.fetchone()
    
    if user:
        sessions_left = user[0]
        if sessions_left > 0:
            # Deduct one session
            sessions_left -= 1
            cursor.execute("UPDATE users SET sessions_left = ? WHERE idno = ?", (sessions_left, user_id))
            conn.commit()
    
    conn.close()
    
    return redirect(url_for('user_dashboard'))


@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))  # Ensure the user is logged in

    # Get user data from the database using the user_id stored in session
    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Fetch user data from the database based on the session's user_id
    cursor.execute('SELECT * FROM users WHERE idno = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()

    if user:
        # Pass the fetched user data to the profile template
        return render_template('profile.html', user=user)
    
    return redirect(url_for('login'))  # Redirect to login if the user is not found
    
@app.route('/update_user_info', methods=['POST'])
def update_user_info():
    try:
        data = request.get_json()
        
        # Get the user data from the request body
        fullname = data['fullname']
        email = data['email']
        course = data['course']
        year_level = data['year_level']
        
        # Extract the username from the fullname (assuming it’s structured as Firstname Lastname)
        username = fullname.split()[0]  # Firstname as username
        
        # Fetch the user from the database using their username
        user = User.query.filter_by(username=username).first()

        if user:
            # Update the user's information
            user.email = email
            user.course = course
            user.year_level = year_level
            db.session.commit()
            
            return jsonify({
                "success": True,
                "message": "Your information has been updated successfully."
            })
        else:
            return jsonify({
                "success": False,
                "message": "User not found."
            }), 404
    except Exception as e:
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500
        
        
# Route for the staff dashboard
@app.route('/staff_dashboard')
def staff_dashboard():
    # Check if the user is logged in (session contains the user key)
    if 'user' not in session:
        # If not logged in, redirect to the login page
        return redirect(url_for('login'))
    
    # If logged in, render the dashboard page
    return render_template('staff_dashboard.html')  # Render the sitin page   
        
# Route for sitin page
@app.route('/sitin')
def sitin():
    return render_template('sitin.html')  # Render the sitin page
    
# Route for sitin page
@app.route('/Reserved')
def Reserved():
    return render_template('Reserved.html')  # Render the sitin page
    
# Route for sitin page
@app.route('/reports')
def reports():
    return render_template('reports.html')  # Render the sitin page
    
    
if __name__ == '__main__':
    app.run(debug=True)
